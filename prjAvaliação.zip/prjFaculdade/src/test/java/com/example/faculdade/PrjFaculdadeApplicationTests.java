package com.example.faculdade;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrjFaculdadeApplicationTests {

	@Test
	void contextLoads() {
	}

}
